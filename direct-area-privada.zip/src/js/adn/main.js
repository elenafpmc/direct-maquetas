/*	----------------------------------------------------------------------------------------------------
	 JS ADN generales
------------------------------------------------------------------------------------------------------ */

$(function() {
		
	/*	--------------------------------------------------
		Inicializamos plugins
	-------------------------------------------------- */
	 $.fn.datepicker.defaults.language = 'es';
	$('.js-datepicker').datepicker(
		{
		    autoclose:true	,
		    disableTouchKeyboard:true
		}
		
	);



	/*	--------------------------------------------------
		Colocamos las tabs responsive
	-------------------------------------------------- */
	
	var anchoVentana= $(window).width();
	//colocamos las tabs en posición para que funcione el plugin
	$('#tabs-datospoliza').insertAfter('#tab-holder');	

	//esperamos e incializamos responsve tabs
	setTimeout(function(){
		
		(function($) {
		      fakewaffle.responsiveTabs(['xs']);
		  })(jQuery);	
			
		
		
	}, 500);

	
	$(window).resize(function(){
		var anchoLayer= $('.content-holder').outerWidth();
		var anchoVentana= $(window).width();
		if (anchoVentana<767){
		
			//colocamos las alertas que estan dentro de las tabs responsive
			$('.selectedInfo .block-alert').css('width',anchoVentana-30);
			$('.selectedInfo .block-alert').css('left',-20);
			
		
		
		}else{
			
			//$('#tabs-datospoliza').appendTo('#tab-holder');
			
				
		   	$('.selectedInfo .block-alert').css('width',anchoLayer+20);
		   	$('.selectedInfo .block-alert').css('left',-30); 			
			
			
			
		}
		console.log(anchoVentana);
	});

});

